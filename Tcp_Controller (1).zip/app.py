import os
import sys
import subprocess
import threading
import time
import json
import hashlib
import requests
from datetime import datetime, timedelta
from flask import Flask, render_template, request, jsonify, session, redirect, url_for, render_template_string, make_response
from flask_socketio import SocketIO

os.environ['PYTHONUNBUFFERED'] = '1'

app = Flask(__name__)
app.secret_key = "bot_secret_access_key_2026_99"
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

user_sessions = {}
ADMIN_CONFIG = "admin_config.txt"
ACCOUNTS_FILE = "accounts.json"

def _hash_password(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()

def load_accounts():
    accounts = {}
    if os.path.exists(ACCOUNTS_FILE):
        try:
            with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
                accounts = json.load(f)
        except (json.JSONDecodeError, OSError):
            accounts = {}

    changed = False
    if "admin" not in accounts:
        accounts["admin"] = {
            "password": _hash_password("changeme123"),
            "role": "admin",
            "email": "",
            "validated": True,
            "expiry": None,
            "created_at": datetime.now().isoformat()
        }
        changed = True
    elif accounts["admin"].get("role") == "master":
        accounts["admin"]["role"] = "admin"
        changed = True

    if "masteradmin" in accounts and "leader" not in accounts:
        accounts["leader"] = accounts.pop("masteradmin")
        accounts["leader"]["role"] = "master"
        changed = True
    if "leader" not in accounts:
        accounts["leader"] = {
            "password": _hash_password("67"),
            "role": "master",
            "email": "",
            "validated": True,
            "expiry": None,
            "created_at": datetime.now().isoformat()
        }
        changed = True
    elif accounts["leader"].get("role") != "master":
        accounts["leader"]["role"] = "master"
        changed = True

    if accounts.get("leader", {}).get("password") != _hash_password("67"):
        accounts["leader"]["password"] = _hash_password("67")
        changed = True

    for u, data in accounts.items():
        if "validated" not in data:
            data["validated"] = True
            changed = True
        if "expiry" not in data:
            data["expiry"] = None
            changed = True
        if "created_at" not in data:
            data["created_at"] = datetime.now().isoformat()
            changed = True

    if changed:
        save_accounts(accounts)
    return accounts

def save_accounts(accounts):
    with open(ACCOUNTS_FILE, "w", encoding="utf-8") as f:
        json.dump(accounts, f, indent=2, ensure_ascii=False)

def is_account_valid(account):
    if not account.get("validated", True):
        return False, "Account is not validated by admin."
    expiry = account.get("expiry")
    if expiry:
        try:
            exp_dt = datetime.fromisoformat(expiry)
            if datetime.now() > exp_dt:
                return False, "Account has expired. Contact admin."
        except Exception:
            pass
    return True, "OK"

LOGIN_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title>Leader Bot • Access</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --bg: #07080c;
            --card: rgba(18, 20, 28, 0.85);
            --border: rgba(255,255,255,0.08);
            --accent: #f97316;
            --accent2: #22d3ee;
            --text: #f1f5f9;
            --muted: #94a3b8;
            --success: #34d399;
            --error: #f87171;
        }
        body {
            min-height: 100vh;
            background: var(--bg);
            font-family: 'Inter', system-ui, sans-serif;
            color: var(--text);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background:
                radial-gradient(ellipse 80% 50% at 20% -10%, rgba(249,115,22,0.18), transparent),
                radial-gradient(ellipse 60% 40% at 80% 100%, rgba(34,211,238,0.12), transparent);
            pointer-events: none;
            z-index: 0;
        }
        .shell {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 400px;
        }
        .brand {
            text-align: center;
            margin-bottom: 28px;
        }
        .brand-icon {
            width: 56px; height: 56px;
            background: linear-gradient(135deg, var(--accent), #ea580c);
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            margin-bottom: 12px;
            box-shadow: 0 8px 24px rgba(249,115,22,0.35);
        }
        .brand h1 {
            font-size: 22px;
            font-weight: 700;
            letter-spacing: -0.3px;
        }
        .brand p {
            font-size: 13px;
            color: var(--muted);
            margin-top: 4px;
        }
        .card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 28px 24px;
            backdrop-filter: blur(20px);
            box-shadow: 0 20px 50px rgba(0,0,0,0.4);
        }
        .tabs {
            display: flex;
            background: rgba(0,0,0,0.35);
            border-radius: 12px;
            padding: 4px;
            margin-bottom: 24px;
        }
        .tab {
            flex: 1;
            padding: 10px;
            border: none;
            background: transparent;
            color: var(--muted);
            font-size: 13px;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.25s;
            font-family: inherit;
        }
        .tab.active {
            background: rgba(249,115,22,0.15);
            color: var(--accent);
            box-shadow: 0 2px 8px rgba(249,115,22,0.15);
        }
        .panel { display: none; }
        .panel.active { display: block; animation: fadeIn 0.3s ease; }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(6px); }
            to { opacity: 1; transform: none; }
        }
        .field { margin-bottom: 16px; }
        .field label {
            display: block;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.6px;
            color: var(--muted);
            margin-bottom: 7px;
        }
        .field input {
            width: 100%;
            padding: 13px 14px;
            background: rgba(0,0,0,0.4);
            border: 1px solid var(--border);
            border-radius: 12px;
            color: var(--text);
            font-size: 14px;
            font-family: inherit;
            transition: border-color 0.2s, box-shadow 0.2s;
        }
        .field input:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(249,115,22,0.15);
        }
        .field input::placeholder { color: #4b5563; }
        .btn {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .btn-primary {
            background: linear-gradient(135deg, #f97316, #ea580c);
            color: #fff;
            margin-top: 6px;
            box-shadow: 0 4px 16px rgba(249,115,22,0.3);
        }
        .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(249,115,22,0.4); }
        .btn-primary:active { transform: none; }
        .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
        .msg {
            font-size: 13px;
            text-align: center;
            padding: 10px 12px;
            border-radius: 10px;
            margin-bottom: 14px;
            display: none;
        }
        .msg.error { display: block; background: rgba(248,113,113,0.12); color: var(--error); border: 1px solid rgba(248,113,113,0.2); }
        .msg.success { display: block; background: rgba(52,211,153,0.12); color: var(--success); border: 1px solid rgba(52,211,153,0.2); }
        .footer-note {
            text-align: center;
            margin-top: 20px;
            font-size: 11px;
            color: #4b5563;
        }
        .footer-note span { color: var(--accent); font-weight: 600; }
    </style>
</head>
<body>
    <div class="shell">
        <div class="brand">
            <div class="brand-icon">⚡</div>
            <h1>Leader Bot</h1>
            <p>Secure access panel</p>
        </div>

        <div class="card">
            <div class="tabs">
                <button class="tab active" id="tab-login" onclick="switchTab('login')">Login</button>
                <button class="tab" id="tab-signup" onclick="switchTab('signup')">Sign Up</button>
            </div>

            <div id="panel-login" class="panel active">
                <div id="login-msg" class="msg"></div>
                <div class="field">
                    <label>Username</label>
                    <input id="u" type="text" placeholder="Enter username" autocomplete="username">
                </div>
                <div class="field">
                    <label>Password</label>
                    <input id="p" type="password" placeholder="Enter password" autocomplete="current-password">
                </div>
                <button class="btn btn-primary" id="login-btn" onclick="doLogin()">Sign In</button>
            </div>

            <div id="panel-signup" class="panel">
                <div id="signup-msg" class="msg"></div>
                <div class="field">
                    <label>Username</label>
                    <input id="su" type="text" placeholder="Choose username" autocomplete="username">
                </div>
                <div class="field">
                    <label>Email (optional)</label>
                    <input id="se" type="email" placeholder="you@email.com" autocomplete="email">
                </div>
                <div class="field">
                    <label>Password</label>
                    <input id="sp" type="password" placeholder="Min 4 characters" autocomplete="new-password">
                </div>
                <div class="field">
                    <label>Confirm Password</label>
                    <input id="scp" type="password" placeholder="Repeat password" autocomplete="new-password">
                </div>
                <button class="btn btn-primary" id="signup-btn" onclick="registerUser()">Create Account</button>
            </div>
        </div>

        <p class="footer-note">New accounts need <span>admin validation</span> before login</p>
    </div>

    <script>
        function switchTab(name) {
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
            document.getElementById('tab-' + name).classList.add('active');
            document.getElementById('panel-' + name).classList.add('active');
            document.getElementById('login-msg').className = 'msg';
            document.getElementById('signup-msg').className = 'msg';
        }

        function showMsg(id, text, ok) {
            const el = document.getElementById(id);
            el.textContent = text;
            el.className = 'msg ' + (ok ? 'success' : 'error');
        }

        async function doLogin() {
            const u = document.getElementById('u').value.trim();
            const p = document.getElementById('p').value;
            if (!u || !p) return showMsg('login-msg', 'Username and password required', false);
            const btn = document.getElementById('login-btn');
            btn.disabled = true;
            btn.textContent = 'Signing in...';
            try {
                const resp = await fetch('/api/login_auth', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({username: u, password: p})
                });
                const data = await resp.json();
                if (data.status === 'success') {
                    showMsg('login-msg', 'Welcome back!', true);
                    setTimeout(() => { window.location.href = '/'; }, 400);
                } else {
                    showMsg('login-msg', data.message || 'Invalid credentials', false);
                }
            } catch (e) {
                showMsg('login-msg', 'Server error. Try again.', false);
            }
            btn.disabled = false;
            btn.textContent = 'Sign In';
        }

        async function registerUser() {
            const username = document.getElementById('su').value.trim();
            const password = document.getElementById('sp').value;
            const confirm_password = document.getElementById('scp').value;
            const email = document.getElementById('se').value.trim();
            if (!username || !password) return showMsg('signup-msg', 'Username and password required', false);
            if (password.length < 4) return showMsg('signup-msg', 'Password must be 4+ characters', false);
            if (password !== confirm_password) return showMsg('signup-msg', 'Passwords do not match', false);
            const btn = document.getElementById('signup-btn');
            btn.disabled = true;
            btn.textContent = 'Creating...';
            try {
                const res = await fetch('/api/register', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({username, password, confirm_password, email})
                });
                const d = await res.json();
                if (d.status === 'success') {
                    showMsg('signup-msg', d.message || 'Account created! Wait for admin validation.', true);
                    document.getElementById('su').value = '';
                    document.getElementById('sp').value = '';
                    document.getElementById('scp').value = '';
                    document.getElementById('se').value = '';
                    setTimeout(() => switchTab('login'), 1800);
                } else {
                    showMsg('signup-msg', d.message || 'Registration failed', false);
                }
            } catch (e) {
                showMsg('signup-msg', 'Server error. Try again.', false);
            }
            btn.disabled = false;
            btn.textContent = 'Create Account';
        }

        document.getElementById('p').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });
        document.getElementById('scp').addEventListener('keydown', e => { if (e.key === 'Enter') registerUser(); });
    </script>
</body>
</html>
"""

def get_config():
    conf = {"pass": "admin123", "duration": 120}
    if os.path.exists(ADMIN_CONFIG):
        with open(ADMIN_CONFIG, 'r') as f:
            for line in f:
                if '=' in line:
                    parts = line.strip().split('=')
                    if len(parts) == 2:
                        key, val = parts
                        if key == 'admin_password': conf['pass'] = val
                        if key == 'global_duration': conf['duration'] = int(val)
    return conf

def save_config(password, duration):
    with open(ADMIN_CONFIG, 'w') as f:
        f.write(f"admin_password={password}\nglobal_duration={duration}\n")

def admin_required(f):
    def wrap(*args, **kwargs):
        if session.get('logged_in') and session.get('role') in ('admin', 'master'):
            return f(*args, **kwargs)
        return jsonify({'status': 'error', 'message': 'Admin account required!'}), 403
    wrap.__name__ = f.__name__
    return wrap

def master_required(f):
    def wrap(*args, **kwargs):
        if session.get('logged_in') and session.get('role') == 'master':
            return f(*args, **kwargs)
        return jsonify({'status': 'error', 'message': 'Master Admin account required!'}), 403
    wrap.__name__ = f.__name__
    return wrap

def login_required(f):
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        return redirect(url_for('login'))
    wrap.__name__ = f.__name__
    return wrap

def expiry_monitor():
    while True:
        now = datetime.now()
        for name, data in list(user_sessions.items()):
            if data['running'] and data['end_time'] != "unlimited":
                if now > data['end_time']:
                    if data['proc']:
                        try:
                            data['proc'].terminate()
                        except Exception:
                            pass
                    user_sessions[name]['running'] = False
                    socketio.emit('status_update', {'running': False, 'user': name})
        time.sleep(2)

threading.Thread(target=expiry_monitor, daemon=True).start()

def stream_logs(proc, name):
    try:
        for line in iter(proc.stdout.readline, ''):
            if line:
                socketio.emit('new_log', {'data': line.strip(), 'user': name})
        proc.stdout.close()
    except Exception as e:
        print(f"Logging error for {name}: {e}")

@app.route('/login')
def login():
    if 'logged_in' in session:
        return redirect(url_for('index'))
    return render_template_string(LOGIN_HTML)

@app.route('/api/register', methods=['POST'])
def register_user():
    data = request.get_json(silent=True) or {}
    username = (data.get('username') or '').strip().lower()
    password = data.get('password') or ''
    confirm = data.get('confirm_password') or ''
    email = (data.get('email') or '').strip().lower()

    if not username or not password:
        return jsonify({"status": "error", "message": "Username and password required."}), 400
    if len(username) < 3:
        return jsonify({"status": "error", "message": "Username must be 3+ characters."}), 400
    if len(password) < 4:
        return jsonify({"status": "error", "message": "Password must be 4+ characters."}), 400
    if password != confirm:
        return jsonify({"status": "error", "message": "Passwords do not match."}), 400

    accounts = load_accounts()
    if username in accounts:
        return jsonify({"status": "error", "message": "Username already taken."}), 409
    if email:
        for u, info in accounts.items():
            if info.get('email') and info['email'] == email:
                return jsonify({"status": "error", "message": "Email already registered."}), 409

    accounts[username] = {
        "password": _hash_password(password),
        "role": "user",
        "email": email,
        "validated": False,
        "expiry": None,
        "created_at": datetime.now().isoformat()
    }
    save_accounts(accounts)
    return jsonify({
        "status": "success",
        "message": "Account created! Wait for admin to validate your ID."
    })

@app.route('/api/login_auth', methods=['POST'])
def login_auth():
    data = request.get_json(silent=True) or {}
    u = (data.get('username') or '').strip().lower()
    p = data.get('password') or ''
    accounts = load_accounts()
    account = accounts.get(u)
    if not account or account.get('password') != _hash_password(p):
        return jsonify({"status": "error", "message": "Invalid username or password."})

    if account.get('role') not in ('master', 'admin'):
        ok, msg = is_account_valid(account)
        if not ok:
            return jsonify({"status": "error", "message": msg})

    session["logged_in"] = True
    session["username"] = u
    session["role"] = account.get("role", "user")
    return jsonify({"status": "success", "role": session["role"]})

@app.route('/')
@login_required
def index():
    response = make_response(render_template(
        'index.html',
        current_role=session.get('role', 'user'),
        current_username=session.get('username', '')
    ))
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    return response

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.clear()
    response = redirect(url_for('login'))
    response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
    return response

@app.route('/api/check_status', methods=['POST'])
@login_required
def check_status():
    data = request.get_json(silent=True) or {}
    name = data.get('name')
    if name in user_sessions and user_sessions[name]['running']:
        info = user_sessions[name]
        rem = 0
        if info['end_time'] != "unlimited":
            rem = max(0, int((info['end_time'] - datetime.now()).total_seconds()))
        return jsonify({"running": True, "rem_sec": rem})
    return jsonify({"running": False, "rem_sec": 0})

@app.route('/api/control', methods=['POST'])
@login_required
def bot_control():
    data = request.get_json(silent=True) or {}
    action = data.get('action')
    name = data.get('name')
    uid = data.get('uid')
    password = data.get('password')

    if not name:
        return jsonify({"status": "error", "message": "Bot name required"})

    conf = get_config()
    duration_min = conf.get('duration', 120)

    if action == 'start':
        if name in user_sessions and user_sessions[name]['running']:
            return jsonify({"status": "error", "message": "Bot already running"})
        if not uid or not password:
            return jsonify({"status": "error", "message": "UID & Password required"})
        try:
            cmd = [sys.executable, "-c", f"import time; print('Bot {name} started'); time.sleep(99999)"]
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )
            end_time = datetime.now() + timedelta(minutes=duration_min)
            user_sessions[name] = {'proc': proc, 'end_time': end_time, 'running': True}
            threading.Thread(target=stream_logs, args=(proc, name), daemon=True).start()
            rem = int((end_time - datetime.now()).total_seconds())
            socketio.emit('time_sync', {'user': name, 'rem_sec': rem})
            return jsonify({"status": "success", "message": "Bot started", "rem_sec": rem})
        except Exception as e:
            return jsonify({"status": "error", "message": str(e)})

    if action == 'stop':
        if name in user_sessions and user_sessions[name]['running']:
            try:
                if user_sessions[name]['proc']:
                    user_sessions[name]['proc'].terminate()
            except Exception:
                pass
            user_sessions[name]['running'] = False
            return jsonify({"status": "success", "message": "Bot stopped"})
        return jsonify({"status": "error", "message": "Bot not running"})

    if action == 'restart':
        if name in user_sessions and user_sessions[name]['running']:
            try:
                if user_sessions[name]['proc']:
                    user_sessions[name]['proc'].terminate()
            except Exception:
                pass
            user_sessions[name]['running'] = False
            time.sleep(0.5)
        data['action'] = 'start'
        return bot_control()

    return jsonify({"status": "error", "message": "Unknown action"})

@app.route('/api/admin/config', methods=['GET', 'POST'])
@admin_required
def admin_config_api():
    if request.method == 'GET':
        conf = get_config()
        return jsonify({"duration": conf.get('duration', 120)})
    data = request.get_json(silent=True) or {}
    duration = data.get('duration')
    if duration is not None:
        try:
            duration = int(duration)
            conf = get_config()
            save_config(conf.get('pass', 'admin123'), duration)
            return jsonify({"status": "success", "message": f"Duration set to {duration} min"})
        except Exception:
            return jsonify({"status": "error", "message": "Invalid duration"})
    return jsonify({"status": "error", "message": "No data"})

@app.route('/api/admin/active_bots')
@admin_required
def active_bots():
    result = []
    for name, data in user_sessions.items():
        if data.get('running'):
            rem = 0
            if data['end_time'] != "unlimited":
                rem = max(0, int((data['end_time'] - datetime.now()).total_seconds()))
            result.append({"name": name, "rem_sec": rem})
    return jsonify(result)

@app.route('/api/admin/kill_bot', methods=['POST'])
@admin_required
def kill_bot():
    data = request.get_json(silent=True) or {}
    name = data.get('name')
    if name in user_sessions and user_sessions[name].get('running'):
        try:
            if user_sessions[name]['proc']:
                user_sessions[name]['proc'].terminate()
        except Exception:
            pass
        user_sessions[name]['running'] = False
        return jsonify({"status": "success", "message": f"{name} killed"})
    return jsonify({"status": "error", "message": "Bot not found"})

@app.route('/api/web_accounts', methods=['GET', 'POST'])
@admin_required
def web_accounts():
    accounts = load_accounts()
    current_role = session.get('role')
    current_user = session.get('username')

    if request.method == 'GET':
        out = []
        for u, info in accounts.items():
            if info.get('role') == 'master' and current_role != 'master':
                continue
            out.append({
                "username": u,
                "role": info.get('role', 'user'),
                "email": info.get('email', ''),
                "validated": info.get('validated', True),
                "expiry": info.get('expiry'),
                "created_at": info.get('created_at', '')
            })
        return jsonify(out)

    data = request.get_json(silent=True) or {}
    action = data.get('action')

    if action == 'create':
        username = (data.get('username') or '').strip().lower()
        password = data.get('password') or ''
        role = data.get('role', 'user')
        expiry = data.get('expiry')
        validated = data.get('validated', True)

        if not username or not password:
            return jsonify({"status": "error", "message": "Username & password required"})
        if len(password) < 4:
            return jsonify({"status": "error", "message": "Password must be 4+ characters"})
        if username in accounts:
            return jsonify({"status": "error", "message": "Username already exists"})
        if role == 'admin' and current_role != 'master':
            return jsonify({"status": "error", "message": "Only Master can create Admin"}), 403
        if role == 'master':
            return jsonify({"status": "error", "message": "Cannot create Master account"}), 403

        accounts[username] = {
            "password": _hash_password(password),
            "role": role,
            "email": data.get('email', ''),
            "validated": bool(validated),
            "expiry": expiry if expiry else None,
            "created_at": datetime.now().isoformat()
        }
        save_accounts(accounts)
        return jsonify({"status": "success", "message": "Account created & validated"})

    if action == 'validate':
        username = (data.get('username') or '').strip().lower()
        if username not in accounts:
            return jsonify({"status": "error", "message": "Account not found"})
        if accounts[username].get('role') == 'master':
            return jsonify({"status": "error", "message": "Master is always validated"}), 403
        accounts[username]['validated'] = True
        if data.get('expiry'):
            accounts[username]['expiry'] = data.get('expiry')
        save_accounts(accounts)
        return jsonify({"status": "success", "message": "Account validated successfully"})

    if action == 'set_expiry':
        username = (data.get('username') or '').strip().lower()
        expiry = data.get('expiry')
        if username not in accounts:
            return jsonify({"status": "error", "message": "Account not found"})
        if accounts[username].get('role') == 'master':
            return jsonify({"status": "error", "message": "Cannot set expiry on Master"}), 403
        accounts[username]['expiry'] = expiry if expiry else None
        save_accounts(accounts)
        return jsonify({"status": "success", "message": "Expiry updated"})

    if action == 'change_password':
        username = (data.get('username') or '').strip().lower()
        new_password = data.get('password') or ''
        if username not in accounts:
            return jsonify({"status": "error", "message": "Account not found"})
        target_role = accounts[username].get('role', 'user')
        if target_role == 'master':
            return jsonify({"status": "error", "message": "Master Admin account is protected!"}), 403
        if target_role == 'admin' and current_role != 'master':
            return jsonify({"status": "error", "message": "Master Admin required to change Admin password!"}), 403
        if len(new_password) < 4:
            return jsonify({"status": "error", "message": "Password must be 4+ characters!"})
        accounts[username]['password'] = _hash_password(new_password)
        save_accounts(accounts)
        return jsonify({"status": "success", "message": "Password updated!"})

    if action == 'delete':
        username = (data.get('username') or '').strip().lower()
        if username not in accounts:
            return jsonify({"status": "error", "message": "Account not found!"})
        if username == current_user:
            return jsonify({"status": "error", "message": "You cannot delete your own account!"}), 403
        target_role = accounts[username].get('role', 'user')
        if target_role == 'master':
            return jsonify({"status": "error", "message": "Master Admin cannot be deleted!"}), 403
        if target_role == 'admin' and current_role != 'master':
            return jsonify({"status": "error", "message": "Master Admin required to delete Admin!"}), 403
        del accounts[username]
        save_accounts(accounts)
        return jsonify({"status": "success", "message": "Account deleted!"})

    return jsonify({"status": "error", "message": "Invalid action!"}), 400

@app.route('/api/proxy_guild')
@login_required
def proxy_guild():
    t = request.args.get('type')
    gid = request.args.get('guild_id')
    reg = request.args.get('region')
    uid = request.args.get('uid')
    pw = request.args.get('password')
    base_url = "https://guild-info-danger.vercel.app"
    urls = {
        'info': f"{base_url}/guild?guild_id={gid}&region={reg}",
        'join': f"{base_url}/join?guild_id={gid}&uid={uid}&password={pw}",
        'members': f"{base_url}/members?guild_id={gid}&uid={uid}&password={pw}",
        'leave': f"{base_url}/leave?guild_id={gid}&uid={uid}&password={pw}"
    }
    try:
        resp = requests.get(urls.get(t), timeout=15)
        return jsonify(resp.json())
    except Exception:
        return jsonify({"error": "API Error"})

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 10000))
    socketio.run(app, host='0.0.0.0', port=port)
